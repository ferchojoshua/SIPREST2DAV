<?php 

class PlantillaControlador {

    /*===================================================================*/
    //llamamos a la plantilla (vistas)
    /*===================================================================*/
    public function CargarPlantilla() {
        include "vistas/plantilla.php";
    }



}

